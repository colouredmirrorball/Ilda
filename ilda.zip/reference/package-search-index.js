packageSearchIndex = [{
    "l": "All Packages",
    "u": "allpackages-index.html"
}, {"l": "be.cmbsoft.laseroutput"}, {"l": "be.cmbsoft.laseroutput.etherdream"}];
updateSearchResults();