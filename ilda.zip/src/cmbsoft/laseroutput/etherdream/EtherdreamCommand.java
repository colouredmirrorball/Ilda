package be.cmbsoft.laseroutput.etherdream;

public interface EtherdreamCommand
{
    byte[] getBytes();

    char getCommandChar();
}
